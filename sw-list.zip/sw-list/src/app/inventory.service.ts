import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ClustersReponse } from './models/ClustersResponse';
import { Cluster } from './models/Cluster';
import { Observable, throwError } from 'rxjs';
import { ProjectsResponse } from './models/ProjectsResponse';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  

  update = false;
  add = false;  
  clusterName : string;
  projectName : string;  
  namespace : string;
  projects: any;
  errorMessage: string = "An Unknow error has occured!";
  error: Boolean = false;

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'my-auth-token',
      'Access-Control-Allow-Origin' : '*',
      'Access-Control-Allow-Headers' : 'Content-Type',
      'Access-Control-Allow-Methods' : 'DELETE, POST, GET, OPTIONS',
      'accept': '*/*'
    })
    
  };

  PostProjects(data: any) {    
    console.log(data);    
    this.client.post<any>('https://ms-dev.windstream.com/playground-dev/swagger-backend/createSwaggerUrl',data,this.httpOptions).subscribe(responseData => {
            console.log(responseData);
            this.router.navigate(['/grid']);
          }, error => {            
            this.error = true;
            this.errorMessage = error.error;
            console.log(this.errorMessage);
            alert(this.errorMessage);
            // if (!error.error) {
            //   this.errorMessage = 'An unknown error occured!'
            // }
            // else {
            //   this.errorMessage = error.error;              
            // }                     
          }
          );
  } 

  UpdateProjects(data: any) {
    console.log(data);    
    this.client.put<any>("https://ms-dev.windstream.com/playground-dev/swagger-backend/updateSwaggerUrl/36",data,this.httpOptions).subscribe(responseData => {
            console.log(responseData);
            this.router.navigate(['/grid']);
          }, error => {            
            this.error = true;
            this.errorMessage = error;
            console.log(this.errorMessage);            
            // if (!error.error) {
            //   this.errorMessage = 'An unknown error occured!'
            // }
            // else {
            //   this.errorMessage = error.error;              
            // }                     
          }
          );
  }

  DeleteProjects(): Observable<any> {        
    return this.client.delete<any>(`https://ms-dev.windstream.com/playground-dev/swagger-backend/deleteSwaggersaaUrl/38`,this.httpOptions);
  }

  GetProjectss(): Observable<any> {    
    return this.client.get<any>(`https://ms-dev.windstream.com/playground-dev/swagger-backend/listSwaggerUrl`,this.httpOptions);
  }

  GetNamespaces(): Observable<any> {
    return this.client.get<any>('https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/namespaces');
  }

  GetClusters(): Observable<any> {
    return this.client.get<any>('https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/clusters');
  }

  GetProjects(): Observable<any> {
    return this.client.get<any>('https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/projects');
  }

  GetUsers(): Observable<any> {
    return this.client.get<any>('https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/users', this.httpOptions);
  }

  constructor(private client: HttpClient, private router: Router) {

  }
}
