import { Directive, EventEmitter, ElementRef, HostListener, Output } from '@angular/core';

@Directive({
  selector: '[appClickOutside]'
})
export class ClickOutsideDirective {

  @Output() clickOutside = new EventEmitter<MouseEvent>();
  @Output() clickInside = new EventEmitter<MouseEvent>();
  constructor(private elementRef: ElementRef) { }

  @HostListener('document:click', ['$event'])
  public onDocumentClick(event: MouseEvent) {
    const targetElement = event.target;
    if(targetElement && this.elementRef.nativeElement.contains(targetElement)) {
      this.clickInside.emit(event);
    }
    else {
      this.clickOutside.emit(event);
    }
  }

}
