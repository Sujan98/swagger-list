import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, PageEvent, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { InventoryService } from '../inventory.service';
import { Cluster } from '../models/Cluster';
import { MicroServiceInfo } from '../models/service';
import * as XLSX from 'xlsx'; 
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { element } from 'protractor';
import { ThrowStmt } from '@angular/compiler';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  displayedColumns: string[] = ['clustername', 'projectname', 'namespace', 'servicename', 'swaggerjsonurl', 'swaggerversion', 'isactive', 'createduser', 'createddate', 'lastupdateuser', 'lastupdatedate', 'edit', 'delete'];
  dataSource: MatTableDataSource<MicroServiceInfo>;  
  microServices: MicroServiceInfo[] = [];
  sampleserv: MicroServiceInfo[];
  namespaces: any = [];
  namespaceSelected: any;
  clusters: any;
  clusterSelected: any;
  projects: any;
  fullProjects: Array<any> = [];
  projectSelected: any;
  loader = true;
  searchedValue = '';
  fileName= 'ExcelSheet.xlsx';
  noOfPages: number;
  pages = [];
  pname;
  sample :MicroServiceInfo;
  noOfItems: number;
  itemsPerPageLabel = 'Page Size';
  currentPage: number;
  hasPreviousPage:boolean;
  hasNextPage:boolean;
  searchOpen = true;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor( private InvtServ: InventoryService, private http: HttpClient) { }

  ngOnInit() {
    this.getClusters();     
    this.createTable();
    this.InvtServ.GetUsers();
    //  this.sample = {
    //   clustername: 'dev-cluster',
    //   projectname: 'middleware',
    //   namespace: 'bw-dev',
    //   servicename: 'ispp',
    //   swaggerjsonurl: 'https://ms-dev.windstream.com/bw-dev/ispp/v2/api-docs',
    //   swaggerversion: 'v2',
    //   isactive: 'y',
    //   createduser: 'e0180072',
    //   createddate: '2020-02-14',
    //   lastupdateuser: 'e0180073',
    //   lastupdatedate: '2020-02-14',
    //   edit: '',
    //   delete: ''
    // }       
    // this.microServices.push(this.sample);        
    // this.sample = {
    //   clustername: 'dev-cluster',
    //   projectname: 'middleware',
    //   namespace: 'bw-dev',
    //   servicename: 'dcris',
    //   swaggerjsonurl: 'https://ms-dev.windstream.com/bw-dev/ispp/v2/api-docs',
    //   swaggerversion: 'v2',
    //   isactive: 'y',
    //   createduser: 'e0180072',
    //   createddate: '2020-02-14',
    //   lastupdateuser: 'e0180073',
    //   lastupdatedate: '2020-02-14',
    //   edit: '',
    //   delete: ''
    // }
    // this.microServices.push(this.sample);        
    // this.newFunc();

    
              // this.http.get(`https://ms-dev.windstream.com/playground-dev/svc-catalog/ui/namespaces`)
              // .pipe(
              //   map(responseData => {
              //     console.log(responseData);                 
              //   })
              // )
              // .subscribe(responseData => {

              //   console.log(responseData);

              // });                                 
  }

  onClusterChange(id) {    
    this.clusterSelected = id;   
    this.getProjects();     
  }

  onProjectChange(id) {    
    this.projectSelected = id;
    this.getNamespaces();
  }

  onNamespaceChange(id) {    
    this.namespaceSelected = id;    
  }

  getClusters() {
    this.InvtServ.GetClusters().subscribe(data => {
      this.clusters = data;
      console.log(this.clusters);
      this.clusterSelected = this.clusters[0].clusterId;           
    });
    setTimeout(() => {
      this.getProjects();
    },200);    
  }

getProjects() {
  this.projects = [];
    this.InvtServ.GetProjects().subscribe(data => {
      console.log(data);
      this.fullProjects = data;
      this.InvtServ.projects = data;
      data.forEach(element => {
        if(element.clusterId == this.clusterSelected) {
          this.projects.push(element);
        }
      });
      console.log(this.projects);
      this.projectSelected = this.projects[0].projectId;           
    }); 
    setTimeout(() => {
      this.getNamespaces();
    },200);    
}

  getNamespaces() {
    this.namespaces = [];
    this.InvtServ.GetNamespaces().subscribe(data => {
      console.log(data);
      data.forEach(element => {
        if(element.clusterId == this.clusterSelected && element.projectId == this.projectSelected) {
          this.namespaces.push(element);
        }
      });
      console.log(this.namespaces);
      this.namespaceSelected = this.namespaces[0].namespace;           
    }); 
  }

// newFunc() {
//   setTimeout(() => {  
//   this.dataSource = new MatTableDataSource(this.microServices);
//         this.dataSource.paginator = this.paginator;
//         this.clearFilter();
//         this.loader = false;
//         this.dataSource.sort = this.sort;
//        this.paginatorChanged();
//   }, 1000);
       
// }

AddEntry() {
  this.clusters.forEach(element => {
    if(element.clusterId == this.clusterSelected) {
      this.InvtServ.clusterName = element.name;
    }
  });
  this.projects.forEach(element => {
    if(element.projectId == this.projectSelected) {
      this.InvtServ.projectName = element.name;
    }
  });  
  this.InvtServ.namespace = this.namespaceSelected;  
  this.InvtServ.add = true;
  this.InvtServ.update = false;
}

UpdateEntry(clusterName: any, projectName: any, namespace: any) {
  this.InvtServ.clusterName = clusterName;
  this.InvtServ.projectName = projectName;
  this.InvtServ.namespace = namespace;
  this.InvtServ.add = false;
  this.InvtServ.update = true;  
}

DeleteEntry() {
  this.InvtServ.DeleteProjects().subscribe(projects => {  
    console.log(projects);
  });  
}

projectName(name: string) {    
  let s='';
  console.log(this.fullProjects);    
    this.fullProjects.forEach(element => {                    
    if(element.projectId == name) {                
      s = element.name;            
    }
  });  
  return s;
}


  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator && (filterValue !== '')) {
      this.dataSource.paginator.firstPage();
    }
    setTimeout(() => {
      this.paginatorChanged();
     }, 50);
  }
  clearFilter() {
    this.dataSource.filter = '';
    this.searchedValue = '';
    setTimeout(() => {
      this.paginatorChanged();
     }, 50);
  }

  createTable() {      
    setTimeout(() => {    
    this.InvtServ.GetProjectss().subscribe(projects => {      
      this.microServices = [];
      console.log(projects);      
      projects.swaggerUrls.forEach(element => {        
        // this.pname = this.projectName(element.projectId);                
        this.sample = {
          clustername: element.clusterId == 'c-zlzc6' ? 'dev-cluster' : element.clusterId == 'c-gkffz' ? 'prod-cluster': element.clusterId == 'local' ? 'rancher-cluster' : '',
          projectname: this.projectName(element.projectId),
          namespace: element.namespace,
          servicename: element.serviceName,
          swaggerjsonurl: element.swaggerJsonUrl,
          swaggerversion: element.swaggerVersion,
          isactive: 'Y',
          createduser: element.createdUser,
          createddate: element.createdDate,
          lastupdateuser: element.lastUpdateUser,
          lastupdatedate: element.lastUpdateDate,
          edit: '',
          delete: ''
        }         
        this.microServices.push(this.sample);
      });

      setTimeout(() => {
        console.log(this.microServices);
        this.dataSource = new MatTableDataSource(this.microServices);
        this.dataSource.paginator = this.paginator;
        this.clearFilter();
        this.loader = false;
        this.dataSource.sort = this.sort;
       this.paginatorChanged();       
      }, 100);
             
      
    });
    },2000);    
  }

  filterTable() {    
    this.loader = false;
    setTimeout(() => {    
      this.InvtServ.GetProjectss().subscribe(projects => {
        this.microServices = [];             
        projects.swaggerUrls.forEach(element => {        
          // this.pname = this.projectName(element.projectId);     
          if(element.clusterId == this.clusterSelected && element.projectId == this.projectSelected && element.namespace == this.namespaceSelected) {
          this.sample = {
            clustername: element.clusterId == 'c-zlzc6' ? 'dev-cluster' : element.clusterId == 'c-gkffz' ? 'prod-cluster': element.clusterId == 'local' ? 'rancher-cluster' : '',
            projectname: this.projectName(element.projectId),
            namespace: element.namespace,
            servicename: element.serviceName,
            swaggerjsonurl: element.swaggerJsonUrl,
            swaggerversion: element.swaggerVersion,
            isactive: 'Y',
            createduser: element.createdUser,
            createddate: element.createdDate,
            lastupdateuser: element.lastUpdateUser,
            lastupdatedate: element.lastUpdateDate,
            edit: '',
            delete: ''
          }         
          this.microServices.push(this.sample);
          }           
        });
  
        setTimeout(() => {          
          this.dataSource = new MatTableDataSource(this.microServices);
          this.dataSource.paginator = this.paginator;
          this.clearFilter();
          this.loader = false;
          this.dataSource.sort = this.sort;
         this.paginatorChanged();       
        }, 100);
      });
    },100);
    this.loader = true;
  }

  gotoFirst() {
    this.dataSource.paginator.firstPage();
  }
  gotoPrev() {
    this.dataSource.paginator.previousPage();
  }
  gotoNext() {
    this.dataSource.paginator.nextPage();
  }
  gotoLast() {
    this.dataSource.paginator.lastPage();
  }
  pageEvent(event) {
    this.paginatorChanged();
  }
  gotoPage(destination) {
    this.dataSource.paginator.pageIndex = destination;
    this.dataSource.paginator.page.next({
      pageIndex: this.dataSource.paginator.pageIndex,
      pageSize: this.dataSource.paginator.pageSize,
      length: this.dataSource.paginator.length
    });
  }
  paginatorChanged(){
    this.hasPreviousPage = this.dataSource.paginator.hasPreviousPage();
    this.hasNextPage =  this.dataSource.paginator.hasNextPage();
    this.currentPage  = this.dataSource.paginator.pageIndex;
    this.noOfItems = this.dataSource.paginator.length;
    this.noOfPages = this.dataSource.paginator.getNumberOfPages();
    this.pages = Array(this.noOfPages).fill(this.noOfPages);
  }

}


