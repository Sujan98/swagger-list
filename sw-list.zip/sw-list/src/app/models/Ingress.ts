import { Labels } from './Labels';
import { PublicEndpoint } from './PublicEndpoint';
import { Annotations } from './Annotations';

export class Ingress {
	name: string;
	namespaceId: string;
	labels: Labels;
	publicEndpoints: PublicEndpoint[];
	annotations: Annotations;
}
