export class PublicEndpoint {
	hostname: string;
	path: string;
	link: string;
}
