import { Project } from './Project';

export class ProjectsResponse {
	projects: Array<Project>;
}
