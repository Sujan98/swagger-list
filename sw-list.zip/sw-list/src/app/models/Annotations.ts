export class Annotations {
	description: string;
}
