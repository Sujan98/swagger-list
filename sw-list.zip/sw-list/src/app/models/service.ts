
export class MicroServiceInfo {    
    clustername: string;
    projectname: string;
    namespace: string;
    servicename: string;
    swaggerjsonurl: string;
    swaggerversion: any;
    isactive: string;
    createduser: any; 
    createddate: any;
    lastupdateuser: any;
    lastupdatedate: any;
    edit : any;
    delete: any;
}
