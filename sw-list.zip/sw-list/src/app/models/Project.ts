import { NameSpace } from './NameSpace';

export class Project {
	clusterId: any;
	createdDate: any;
	createdUser: string;
	isDeleted: string;
	lastUpdateDate: any;
	lastUpdateUser: string;
	namespace: string;
	projectId: any;	
	serviceName: string;
	swaggerJsonUrl: string;	
	swaggerVersion: string;
}
