export class Cluster {
	public id: string;
	public name: string;
}