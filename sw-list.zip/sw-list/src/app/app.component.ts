import { Component } from '@angular/core';
import { OidcSecurityService } from 'angular-auth-oidc-client';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  constructor(private oidcSecurityService: OidcSecurityService) {
    
    this.login();

  }
  login() {
      this.oidcSecurityService.authorize((authUrl) => {
          // handle the authorrization URL
          window.open(authUrl, 'toolbar=0,location=0,menubar=0');
      });
  }
}
