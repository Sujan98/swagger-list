import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { AuthModule, ConfigResult, OidcConfigService, OidcSecurityService, OpenIdConfiguration } from 'angular-auth-oidc-client';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import {MatTableModule} from '@angular/material/table';
import {CdkTableModule} from '@angular/cdk/table';
import { AppComponent } from './app.component';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { GridComponent } from './grid/grid.component';
import {MatFormFieldModule, MatPaginatorModule, MatSelectModule, MatInputModule,  MatSortModule, MatPaginatorIntl  } from '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { CommonService } from './services/common.service'; 
import { InventoryService } from './inventory.service';
import { ClickOutsideDirective } from './click-outside.directive';

const oidc_configuration = 'assets/auth.clientConfiguration.json';
// if your config is on server side
// const oidc_configuration = ${window.location.origin}/api/ClientAppSettings
 
export function loadConfig(oidcConfigService: OidcConfigService) {
    return () => oidcConfigService.load(oidc_configuration);
}


@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent,
    GridComponent,
    ClickOutsideDirective
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    MatTableModule,
    CdkTableModule,
    MatFormFieldModule,
    NgbModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatInputModule,
    MatSortModule,
    MatIconModule,
    ReactiveFormsModule,
    AuthModule.forRoot(),
    RouterModule.forRoot([
      { path: '', component: GridComponent, pathMatch: 'full' },      
      { path: 'add', component: FetchDataComponent },
      { path: 'grid', component: GridComponent }
    ])
  ],
  providers: [CommonService, InventoryService,MatPaginatorIntl,OidcConfigService,
    {
        provide: APP_INITIALIZER,
        useFactory: loadConfig,
        deps: [OidcConfigService],
        multi: true,
    }, ],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor(private oidcSecurityService: OidcSecurityService, private oidcConfigService: OidcConfigService) {
    this.oidcConfigService.onConfigurationLoaded.subscribe((configResult: ConfigResult) => {
    
        // Use the configResult to set the configurations
        
        const config: OpenIdConfiguration = {
            stsServer: 'https://localhost:4200',
            redirect_url: 'https://localhost:4200',
            client_id: 'ebf3ba22-f0ba-4012-ae6b-468ed1a123c6',
            scope: 'openid profile email',
            response_type: 'code',
            silent_renew: true,
            silent_renew_url: 'https://localhost:4200/silent-renew.html',
            log_console_debug_active: true,
            // all other properties you want to set
        };

        this.oidcSecurityService.setupModule(config, configResult.authWellknownEndpoints);
    });
}

 }
