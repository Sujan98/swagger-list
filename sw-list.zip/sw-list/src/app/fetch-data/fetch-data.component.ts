import { Directive, Component, Inject, OnInit, ViewChild, ElementRef, HostListener, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { InventoryService } from '../inventory.service';
import { Router } from '@angular/router';
import { NgForm, FormControl, FormGroup, Validators } from '@angular/forms';
import { MicroServiceInfo } from '../models/service';
import { Project } from '../models/Project';
import { Observable } from 'rxjs';
import { element } from 'protractor';


@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html',
  styleUrls: ['./fetch-data.component.css']
})
export class FetchDataComponent {  
  @ViewChild('div',{static: true}) click: ElementRef;
  isupdate = this.InvtServ.update;
  isadd = this.InvtServ.add;
  clusterName : string = this.InvtServ.clusterName;
  projectName : string = this.InvtServ.projectName;
  clusterId: any;
  projectId: any;
  nameSpace : string = this.InvtServ.namespace;
  ProjectData: Project;
  Projects: any = this.InvtServ.projects;
  error: Boolean = this.InvtServ.error;
  errorMessage: any = this.InvtServ.errorMessage;
  selectedIsActive: any = 'Y';
  selectedVersion: any = 'V2';
  users: any = [];
  filteredUsers:any = [];
  selectedUser: any;
  isDrop: boolean = false;  
  
closeDrop(data) {
  this.isDrop = false;
}

openDrop(data) {
  this.isDrop = true;
}

  ngOnInit() {
    if(this.isadd == false && this.isupdate == false) {
      this.router.navigate(['/grid']);
    }
    else {    
    this.getUsers();
    setTimeout(() => {
      console.log(this.users.length);
      this.filteredUsers = Object.assign([], this.users);
    }, 2000);
  }
  }

  getUsers() {
    this.InvtServ.GetUsers().subscribe(data => {
      console.log(data);      
      data.forEach(element => {
        if(element.samaccountName != null) {
          this.users.push(element);
        }
      });
    });
  }

  filterUser(data) { 
    this.isDrop = true; 
    if(!data.target.value) {
      this.filteredUsers = Object.assign([], this.users);
    }
    this.filteredUsers = Object.assign([], this.users).filter(
      user => user.samaccountName.toUpperCase().indexOf(data.target.value.toUpperCase()) > -1
    )
    if(this.filteredUsers.length == 0) {
      this.isDrop = false;
    }
  }

  selectUser(user) {
    this.selectedUser = user;   
    this.isDrop = false; 
  }

  onSubmit(l) {        
    this.ProjectData = {
     createdDate: "28-02-2020 02:18:37",
      lastUpdateDate: "28-02-2020 02:18:37",
      createdUser: "system",
      lastUpdateUser: "system",      
      clusterId: "c-gkffz",
      projectId: "c-gkffz:p-6h7n9",
      namespace: "chatbot-prod",
      serviceName: "chatbot-svc",
      swaggerJsonUrl: "http://ms-prod.windstreamossnn.com/chat-bot/v1/api",
      swaggerVersion: "v1",
      isDeleted: "N"
    }   

    // createdDate: "28-02-2020 02:18:37",
    //   lastUpdateDate: "28-02-2020 02:18:37",
    //   createdUser: "system",
    //   lastUpdateUser: "system",      
    //   clusterId: l.value.clustername == 'dev-cluster' ? 'c-zlzc6' : l.value.clustername == 'prod-cluster' ? 'c-gkffz': l.value.clustername == 'rancher-cluster' ? 'local' : '',
    //   projectId: this.getProjectId(l.value.projectname),
    //   namespace: l.value.namespace,
    //   serviceName: l.value.servicename,
    //   swaggerUrlId: 0,
    //   swaggerJsonUrl: l.value.swaggerurl,
    //   swaggerVersion: "v1",
    //   isDeleted: "N"

    //   clustername: 'dev-cluster',
    //   projectname: 'middleware',
    //   namespace: 'bw-dev',
    //   servicename: 'dcris',
    //   swaggerjsonurl: 'https://ms-dev.windstream.com/bw-dev/ispp/v2/api-docs',
    //   swaggerversion: 'v2',
    //   isactive: 'y',
    //   createduser: 'e0180072',
    //   createddate: '2020-02-14',
    //   lastupdateuser: 'e0180073',
    //   lastupdatedate: '2020-02-14',
    //   edit: '',
    //   delete: ''    
    console.log(this.ProjectData);    
    if(this.isadd) {
      this.InvtServ.PostProjects(this.ProjectData);
    }    
    else if (this.isupdate) {
      this.InvtServ.UpdateProjects(this.ProjectData);
    }
   
  }

// getClusterId(clustername) {
//   let name;
//   this.InvtServ.GetClusters().subscribe(data => {
//     data.forEach(element => {
//       if(element.name == clustername) {
//         name = this.clusterId;
//       }
//     });
//   });
//   return name;
// }

// getProjectId(projectname: any) {  
//   let id;
//     this.Projects.forEach(element => {
//       if(element.name == projectname) {
//         id = element.projectId;      
//       }
//     });  
//     console.log(id);
//     return id;    
// }

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string, private InvtServ: InventoryService, private router: Router) {
    
  }
}

